package com.chartboost.sdk.sample.cbtest;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

import com.chartboost.sdk.CBPreferences;
import com.chartboost.sdk.Libraries.CBLogging.Level;
import com.chartboost.sdk.sample.R;

public class CBHomeActivity extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.home);
		CBPreferences.getInstance().setLoggingLevel(Level.ALL);
	}
	
	public void gotoActivityA(View view) {
		this.startActivity(new Intent(this, CBTestActivityA.class));
	}
	
	public void gotoActivityB(View view) {
		this.startActivity(new Intent(this, CBTestActivityB.class));
	}

	public void gotoActivityC(View view) {
		this.startActivity(new Intent(this, CBTestActivityC.class));
	}
	
	public void gotoActivitySimple(View view) {
		this.startActivity(new Intent(this, CBTestActivitySimple.class));
	}
	
	public void gotoGoogleActivityIAP(View view) {
		if(!isKindleFire())
			this.startActivity(new Intent(this, CBPostInstallTrackActivity.class));
		else
			 Toast.makeText(getApplicationContext(), 
                     "Please run it on a non-amazon devices", Toast.LENGTH_LONG).show();
	}
	
	public void gotoAmazonActivityIAP(View view) {
		if(isKindleFire())
			this.startActivity(new Intent(this, CBAmazonIAPActivity.class));
		else
			 Toast.makeText(getApplicationContext(), 
                     "Please run it on a Amazon Device", Toast.LENGTH_LONG).show();
	}
	
	public static boolean isKindleFire() {
	    return android.os.Build.MANUFACTURER.equals("Amazon")
	            && (android.os.Build.MODEL.equals("Kindle Fire")
	                || android.os.Build.MODEL.startsWith("KF"));
	}
}