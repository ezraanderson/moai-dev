package com.chartboost.sdk.sample.cbtest;

import java.util.HashSet;
import java.util.Set;

import com.amazon.inapp.purchasing.Item;
import com.amazon.inapp.purchasing.PurchasingManager;
import com.chartboost.sdk.Chartboost;
import com.chartboost.sdk.Tracking.CBPostInstallTracker;
import com.chartboost.sdk.sample.R;


import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class CBAmazonIAPActivity extends Activity {
    private Chartboost cb;
    CBPostInstallTracker pit;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.amazoniap);
		// Configure Chartboost
		this.cb = Chartboost.sharedChartboost();
		String appId = "";
		String appSignature = "";
		
		// create!
		this.cb.onCreate(this, appId, appSignature, null);
	}
	
		 public void displayItem(Item item)
		 {
		    	TextView titleText = (TextView) findViewById(R.id.titleText);
		    	TextView descriptionText = 
	                   (TextView) findViewById(R.id.descriptionText);
		    	TextView priceText = (TextView) findViewById(R.id.priceText);
		    	
		  	titleText.setText("Item: " + item.getTitle());
		    	descriptionText.setText("Desc: " + 
	                              item.getDescription());
		    	priceText.setText("Price: $" + item.getPrice());
		 }
		 
		 public void makePurchase(View view)
		 {
		    String skuString = getResources().getString(R.string.consumable_sku);
		    PurchasingManager.initiatePurchaseRequest(skuString);
		 }
		 
		 public void unlockImage()
		 {
		 	ImageView image = (ImageView) findViewById(R.id.imageView1);
		 	image.setImageResource(R.drawable.chartboost);
		 }
		 
	
	/*Activity callback methods*/
	@Override
	protected void onStart() {
		super.onStart();
		this.cb.onStart(this);

	     InAppObserver observer = new InAppObserver(this);
	     PurchasingManager.registerObserver(observer);
	        
	     Set<String>skuList = new HashSet<String>(1);
	     skuList.add(getResources().getString(R.string.consumable_sku));
	     
	     PurchasingManager.initiateItemDataRequest(skuList);
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		System.out.println("### onResume");
        PurchasingManager.initiateGetUserIdRequest();
		pit= CBPostInstallTracker.sharedPostInstallTracker();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	protected void onStop() {
		super.onStop();
		this.cb.onStop(this);
	}

	@Override
	public void onBackPressed() {
		if (this.cb.onBackPressed())
			return;
		else
			super.onBackPressed();
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		this.cb.onDestroy(this);
	}

}
