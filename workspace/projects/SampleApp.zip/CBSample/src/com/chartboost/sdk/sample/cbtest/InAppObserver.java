package com.chartboost.sdk.sample.cbtest;

import java.util.Currency;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import android.app.AlertDialog;
import android.util.Log;

import com.amazon.inapp.purchasing.GetUserIdResponse;
import com.amazon.inapp.purchasing.Item;
import com.amazon.inapp.purchasing.ItemDataResponse;
import com.amazon.inapp.purchasing.PurchaseResponse;
import com.amazon.inapp.purchasing.PurchaseUpdatesResponse;
import com.amazon.inapp.purchasing.PurchasingObserver;
import com.amazon.inapp.purchasing.Receipt;
import com.chartboost.sdk.Tracking.CBPostInstallTracker;
import com.chartboost.sdk.Tracking.CBPostInstallTracker.CBIAPPurchaseInfo;
import com.chartboost.sdk.Tracking.CBPostInstallTracker.CBIAPType;

public class InAppObserver extends PurchasingObserver {

	private final CBAmazonIAPActivity baseActivity;
	private HashMap<String, Item> itemInfo;
	private CBPostInstallTracker pit;
	public InAppObserver(final CBAmazonIAPActivity buyerActivity) {
        super(buyerActivity);
        this.baseActivity = buyerActivity;
        this.pit =  CBPostInstallTracker.sharedPostInstallTracker();
		this.itemInfo = new HashMap<String, Item>();
     }

	@Override
	public void onGetUserIdResponse(GetUserIdResponse arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onItemDataResponse(ItemDataResponse itemDataResponse) {
		
		switch (itemDataResponse.getItemDataRequestStatus()) {
		 
			case SUCCESSFUL:
				final Map<String, Item> items = 
                              itemDataResponse.getItemData();
        
				for (final String key : items.keySet()) {
					Item i = items.get(key);
					itemInfo.put(i.getSku(), i);
					baseActivity.displayItem(i);
				}
				break;
			case SUCCESSFUL_WITH_UNAVAILABLE_SKUS:
				// Handle Unavailable SKUs
			    break;
			case FAILED:
				// Handle failure
				break;
        }
    }

	@Override
	public void onPurchaseResponse(PurchaseResponse purchaseResponse) {
		Log.d(InAppObserver.class.getSimpleName(),"###### Response"+purchaseResponse);
		switch (purchaseResponse.getPurchaseRequestStatus()) {
	    		case SUCCESSFUL:
	    			  Receipt receipt = purchaseResponse.getReceipt();
	    	          String purchaseToken = receipt.getPurchaseToken();
	    	          String userId = purchaseResponse.getUserId();
	    	          String sku = receipt.getSku();
	    	          Item productInfo = itemInfo.get(sku);
					  Locale locale = Locale.getDefault();
					  Currency currency = Currency.getInstance(locale);
					  EnumMap<CBIAPPurchaseInfo, String> map = new EnumMap<CBIAPPurchaseInfo, String>(CBIAPPurchaseInfo.class);
							map.put(CBIAPPurchaseInfo.PRODUCT_ID, productInfo.getSku());
							map.put(CBIAPPurchaseInfo.PRODUCT_TITLE,productInfo.getTitle());
							map.put(CBIAPPurchaseInfo.PRODUCT_DESCRIPTION, productInfo.getDescription());
							map.put(CBIAPPurchaseInfo.PRODUCT_PRICE, productInfo.getPrice());
							map.put(CBIAPPurchaseInfo.PRODUCT_CURRENCY_CODE, currency.getCurrencyCode());
							map.put(CBIAPPurchaseInfo.AMAZON_USER_ID, userId);
							map.put(CBIAPPurchaseInfo.AMAZON_PURCHASE_TOKEN, purchaseToken );
							pit.trackInAppPurchaseEvent(map,CBIAPType.AMAZON);
	    	          baseActivity.unlockImage();
	    			break;
	    		case FAILED:
	    			// Add code to handle purchase failure if necessary
	    		case INVALID_SKU:
	    			// Add code to handle invalid SKU if necessary
	    			AlertDialog.Builder builder = new 
					AlertDialog.Builder(baseActivity);
	    			builder.setMessage("Invalid Product SKU")
	    	       		.setTitle("Purchase could not be completed");
	    			AlertDialog dialog = builder.create();
	    			dialog.show();
		default:
			break;
	        }
	}

	@Override
	public void onPurchaseUpdatesResponse(PurchaseUpdatesResponse arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onSdkAvailable(boolean arg0) {
		// TODO Auto-generated method stub

	}

}
